//
//  SongDetailViewController.swift
//  sta
//
//  Created by User19 on 2019/6/23.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit
import AVKit

class SongDetailViewController: UIViewController {
    
     var song: Song?

    @IBOutlet weak var cotent: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        if let song = song {
            navigationItem.title = song.trackName
            
            if song.trackName == "Kill This Love"{
                cotent.text = "<Kill This Love>顧名思義就是要結束感情的意思，訴說很多現代女生的愛情觀，不願意就此分開，明知對方不是對的人，因為習慣了在一起的日子，不願意就此分開，而互相傷害，聽了這首歌，或許你也會強硬起來，面對自己的感情！"
            }
            
            if song.trackName == "BOOMBAYAH"{
                cotent.text = "〈Boombayah〉是BLACKPINK的出道專輯《Square One》收錄的首支主打曲強而有力、重低音的強勁節奏，以及充滿力量的副歌，有著YG娛樂獨特色彩的音樂風格。"
            }
            
            if song.trackName == "DDU-DU DDU-DU"{
                cotent.text = "<DDU-DU DDU-DU>的MV成為史上最快在Youtube上點擊率達７千萬的歌曲，打破一眾女團紀錄，說到這首人氣作品，歌名其實是槍聲的意思，直接向批評過Blackpink的Haters嗆聲"
            }
            let task = URLSession.shared.dataTask(with: song.artworkUrl100) { (data, response , error) in
                if let data = data {
                    DispatchQueue.main.async {
                        self.imageView.image = UIImage(data: data)
                    }
                }
            }
            task.resume()
        }
        
        
        // Do any additional setup after loading the view.
    }
    

    var player: AVPlayer?
    
    @IBAction func play(_ sender: Any) {
        if let url = song?.previewUrl {
            player = AVPlayer(url: url)
            player?.play()
            
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
