//
//  personalpageViewController.swift
//  sta
//
//  Created by User16 on 2019/6/19.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit

class personalpageViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource{
    @IBOutlet weak var collectionViewControl: UICollectionView!
    @IBOutlet weak var collectionLayout: UICollectionViewFlowLayout!
    func  numberOfItemsInSection(in collectionView:UICollectionView)-> Int {
        return 1
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView,numberOfItemsInSection section: Int) -> Int {
        return photoArray.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let userDefault = UserDefaults.standard
        let achieveTimenum = userDefault.integer(forKey: "Int")
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "achievement", for: indexPath) as! CollectionViewCell
        //cell.cellImage.image = UIImage(named: photoArray[indexPath.row])
        cell.cellImage.image = UIImage(named: "unknown")
       cell.cellButton.tag = indexPath.row
        cell.cellButton.addTarget(self, action: #selector(achievementDoc(_:)) ,for: .touchUpInside)
       cell.cellImage.clipsToBounds = true
        cell.cellImage.layer.cornerRadius = 10
        print(achieveTimenum)
        if achieveTimenum > 1 && indexPath.row == 0{
            cell.cellImage.image = UIImage(named:"achievement1" )
        }
        if achieveTimenum > 10 && indexPath.row == 1{
            cell.cellImage.image = UIImage(named:"achievement2" )
        }
        if achieveTimenum > 20 && indexPath.row == 2{
            cell.cellImage.image = UIImage(named:"achievement3" )
        }
        if achieveTimenum > 30 && indexPath.row == 3{
            cell.cellImage.image = UIImage(named:"achievement4" )
        }
        if achieveTimenum > 40 && indexPath.row == 4{
            cell.cellImage.image = UIImage(named:"achievement5" )
        }
        return cell
    }
    
    
    
    @IBOutlet weak var background: UIView!
    @IBOutlet weak var userphoto: UIImageView!
    @IBOutlet weak var photoButton: UIButton!
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var usernamee: UILabel!
    @IBOutlet weak var settings: UIButton!
    
    @IBOutlet weak var achieveLabel: UILabel!
    @IBOutlet weak var messAge: UILabel!
    var userAccount: String!
    var name: String!
    
    var photoArray: [String] = ["achievement1","achievement2","achievement3","achievement4","achievement5"]
    var mmesage: String!
    var achieveTimenum:Int = 0
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[.editedImage] as? UIImage
        
        userphoto.image = image
       
        
        dismiss(animated: true, completion: nil)
        
    }
    override func viewDidLoad() {
        
        background.clipsToBounds = true
        background.layer.cornerRadius = 30
        
        let userDefault = UserDefaults.standard
        userphoto.clipsToBounds = true
        userphoto.layer.cornerRadius = 44
      
       
        let name = userDefault.string(forKey: "userName")
        
        usernamee.text = name
        super.viewDidLoad()
        
        collectionLayout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        collectionLayout.itemSize = CGSize(width: 73, height: 73)
        collectionLayout.scrollDirection = .vertical
        
        //userrname.text = userName
        // Do any additional setup after loading the view.
    }
    

    @IBAction func Selectphoto(_ sender: Any) {
        let controller = UIImagePickerController()
        controller.sourceType = .photoLibrary
        controller.allowsEditing = true
        controller.delegate = self
        present(controller, animated: true, completion: nil)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func click(_ sender: Any) {
        let userDefault = UserDefaults.standard
        let mmesage = userDefault.string(forKey: "usermessage")
        messAge.text = mmesage
    }
    
    @IBAction func achievementDoc(_ sender: UIButton) {
        print(sender.tag)
        
        if sender.tag == 0  {
            titleLabel.text = "小小萌新"
            achieveLabel.text = "完成一次遊戲"
        }
        if sender.tag == 1  {
            titleLabel.text = "小試身手"
            achieveLabel.text = "最佳紀錄超過10秒"
        }
        if sender.tag == 2  {
            titleLabel.text = "漸入佳境"
            achieveLabel.text = "最佳紀錄超過20秒"
        }
        if sender.tag == 3  {
            titleLabel.text = "得心應手"
            achieveLabel.text = "最佳紀錄超過30秒"
        }
        if sender.tag == 4  {
            titleLabel.text = "弓馬嫻熟"
            achieveLabel.text = "最佳紀錄超過40秒"
        }
    }
    
}
