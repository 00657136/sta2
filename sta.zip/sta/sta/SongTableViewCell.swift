//
//  SongTableViewCell.swift
//  sta
//
//  Created by User19 on 2019/6/23.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit

class SongTableViewCell: UITableViewCell {
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var AlbumTitle: UILabel!
    @IBOutlet weak var Album: UILabel!
    @IBOutlet weak var AlbumPrice: UILabel!
    @IBOutlet weak var AlbumPriceUSD: UILabel!
    @IBOutlet weak var KPOP: UILabel!
    @IBOutlet weak var USD: UILabel!
    
    @IBOutlet weak var bb: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
