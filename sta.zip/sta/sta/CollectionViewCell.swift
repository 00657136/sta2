//
//  CollectionViewCell.swift
//  sta
//
//  Created by User15 on 2019/6/22.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
    
    @IBOutlet weak var cellButton: UIButton!
    
}
