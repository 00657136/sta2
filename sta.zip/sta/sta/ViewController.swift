//
//  ViewController.swift
//  sta
//
//  Created by User23 on 2019/5/11.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit
import UserNotifications
class ViewController: UIViewController {
    @IBOutlet weak var characterImageView: UIImageView!
    
    @IBOutlet weak var chessValueLabel: UILabel!
    @IBOutlet weak var coin4: UIImageView!
    @IBOutlet weak var coin3: UIImageView!
    @IBOutlet weak var coin2: UIImageView!
    @IBOutlet weak var coin1: UIImageView!
    @IBOutlet weak var coin0: UIImageView!
    @IBOutlet weak var coin11: UIImageView!
    @IBOutlet weak var coin22: UIImageView!
    @IBOutlet weak var stair4: UIImageView!
    @IBOutlet weak var stair3: UIImageView!
    @IBOutlet weak var stair2: UIImageView!
    @IBOutlet weak var stair1: UIImageView!
    @IBOutlet weak var stair0: UIImageView!
    @IBOutlet weak var stair11: UIImageView!
    @IBOutlet weak var stair22: UIImageView!
    @IBOutlet weak var timerLabel: UILabel!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let controller = segue.destination as! recordViewController
        controller.M = minute
        controller.S = second
        controller.bestMinute = Bminute
        controller.bestSecond = Bsecond
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if(pickCharacter==Rose.player){
            characterImageView.image = #imageLiteral(resourceName: "rose1")
        }
        else if(pickCharacter==Lisa.player){
            characterImageView.image = #imageLiteral(resourceName: "Lisa1")
        }
        else if(pickCharacter==Jennie.player){
            characterImageView.image = #imageLiteral(resourceName: "jennie1")
        }
        else if(pickCharacter==Jisoo.player){
            characterImageView.image = #imageLiteral(resourceName: "jisoo1")
        }
        if(pickCharacter==Rose.player){
            chessValueLabel.text = "\(Rose.playerName)"
        }
        else if(pickCharacter==Lisa.player){
            chessValueLabel.text = "\(Lisa.playerName)"
        }
        else if(pickCharacter==Jennie.player){
            chessValueLabel.text = "\(Jennie.playerName)"
        }
        else if(pickCharacter==Jisoo.player){
            chessValueLabel.text = "\(Jisoo.playerName)"
        }
        // Do any additional setup after loading the view.
    }
    
    
    class selectCharacter {
        let player :Int
        let playerName : String
        init(player: Int,playerName: String) {
            self.player = player
            self.playerName = playerName
        }
    }
    let Lisa = selectCharacter(player: 0, playerName: "Lisa")
    let Jennie = selectCharacter(player: 1, playerName: "Jennie")
    let Jisoo = selectCharacter(player: 2, playerName: "Jisoo")
    let Rose = selectCharacter(player: 3, playerName: "Rose")
    var timer2:Timer?
    var steps:Int = 0
    var wall:Int = 0
    var minute:Int = 0
    var Bminute:Int = 0
    var Bsecond:Int = 0
    var second:Int = 0
    var timer:Timer?
    var startORpause:Int = 0
    var chess:Int = 0
    var stairApear:Int?
    var stairReturn:Int = 0
    var pickCharacter:Int?
    @IBAction func restartButtom(_ sender: Any) {
        
        if(pickCharacter==Rose.player){
            characterImageView.image = #imageLiteral(resourceName: "rose1")
        }
        else if(pickCharacter==Lisa.player){
            characterImageView.image = #imageLiteral(resourceName: "Lisa1")
        }
        else if(pickCharacter==Jennie.player){
            characterImageView.image = #imageLiteral(resourceName: "jennie1")
        }
        else if(pickCharacter==Jisoo.player){
            characterImageView.image = #imageLiteral(resourceName: "jisoo1")
        }
       
        characterImageView.frame.origin = CGPoint(x: 97, y: 258)
        stair4.frame.origin = CGPoint(x: 363, y: 376)
        stair3.frame.origin = CGPoint(x: 303, y: 376)
        stair2.frame.origin = CGPoint(x: 244, y: 376)
        stair1.frame.origin = CGPoint(x: 184, y: 376)
        stair0.frame.origin = CGPoint(x: 123, y: 376)
        stair11.frame.origin = CGPoint(x: 61, y: 376)
        stair22.frame.origin = CGPoint(x: 0, y: 376)
        coin4.frame.origin = CGPoint(x: 368,y: 340)
        coin3.frame.origin = CGPoint(x: 313,y: 340)
        coin2.frame.origin = CGPoint(x: 253,y: 340)
        coin1.frame.origin = CGPoint(x: 192,y: 340)
        coin0.frame.origin = CGPoint(x: 133,y: 340)
        coin11.frame.origin = CGPoint(x: 69,y: 340)
        coin22.frame.origin = CGPoint(x: 10,y: 340)
        coin4.isHidden = true
        coin3.isHidden = true
        coin2.isHidden = true
        coin1.isHidden = true
        coin0.isHidden = true
        coin11.isHidden = true
        coin22.isHidden = true
        steps=0
        wall=0
        second = 0
        minute = 0
        chess=0
        if(pickCharacter==Rose.player){
            chessValueLabel.text = "\(Rose.playerName)"
        }
        else if(pickCharacter==Lisa.player){
            chessValueLabel.text = "\(Lisa.playerName)"
        }
        else if(pickCharacter==Jennie.player){
            chessValueLabel.text = "\(Jennie.playerName)"
        }
        else if(pickCharacter==Jisoo.player){
            chessValueLabel.text = "\(Jisoo.playerName)"
        }
        startORpause = 0
        stairReturn = 0
        if timer != nil{
            timer?.invalidate()
        }
        timerLabel.text = "\(self.minute):0\(self.second)"
    }
    
    @IBAction func start(_ sender: Any) {
        if minute*60+second >= Bminute*60+Bsecond{
            Bminute = minute
            Bsecond = second
        }
        if pickCharacter == Rose.player || pickCharacter == Lisa.player || pickCharacter == Jennie.player || pickCharacter == Jisoo.player{
        startORpause += 1
        }
        if startORpause == 1 {
            timer2 = Timer.scheduledTimer(withTimeInterval: 2.2, repeats: true){(_)in
                self.stairApear = Int.random(in: -2...7)
                self.coin4.isHidden = true
                self.coin3.isHidden = true
                self.coin2.isHidden = true
                self.coin1.isHidden = true
                self.coin0.isHidden = true
                self.coin11.isHidden = true
                self.coin22.isHidden = true
            }
        timer=Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (_) in
            self.second += 1
            if self.second == 60 {
                self.minute += 1
                self.second = 0
            }
            if self.second < 10{
                self.timerLabel.text = "\(self.minute):0\(self.second)"
            }
            if self.second >= 10{
                self.timerLabel.text = "\(self.minute):\(self.second)"
            }
            if(self.pickCharacter==self.Rose.player){
                self.chessValueLabel.text = "\(self.Rose.playerName)"
            }
            else if(self.pickCharacter==self.Lisa.player){
                self.chessValueLabel.text = "\(self.Lisa.playerName)"
            }
            else if(self.pickCharacter==self.Jennie.player){
                self.chessValueLabel.text = "\(self.Jennie.playerName)"
            }
            else if(self.pickCharacter==self.Jisoo.player){
                self.chessValueLabel.text = "\(self.Jisoo.playerName)"
            }
            self.characterImageView.frame.origin.y += 5
            self.chess += 1
            
            
            self.stair4.frame.origin.y += 5
            self.stair3.frame.origin.y += 5
            self.stair2.frame.origin.y += 5
            self.stair1.frame.origin.y += 5
            self.stair0.frame.origin.y += 5
            self.stair11.frame.origin.y += 5
            self.stair22.frame.origin.y += 5
            self.coin4.frame.origin.y += 5
            self.coin3.frame.origin.y += 5
            self.coin2.frame.origin.y += 5
            self.coin1.frame.origin.y += 5
            self.coin0.frame.origin.y += 5
            self.coin11.frame.origin.y += 5
            self.coin22.frame.origin.y += 5
            if self.stairApear == 4{
                self.coin4.isHidden = false
                if self.wall == 4{
                    self.characterImageView.frame.origin.y -= 30
                    self.chess -= 6
                    
                    
                    self.stair4.frame.origin.y -= 30
                    self.stair3.frame.origin.y -= 30
                    self.stair2.frame.origin.y -= 30
                    self.stair1.frame.origin.y -= 30
                    self.stair0.frame.origin.y -= 30
                    self.stair11.frame.origin.y -= 30
                    self.stair22.frame.origin.y -= 30
                    self.coin4.frame.origin.y -= 30
                    self.coin3.frame.origin.y -= 30
                    self.coin2.frame.origin.y -= 30
                    self.coin1.frame.origin.y -= 30
                    self.coin0.frame.origin.y -= 30
                    self.coin11.frame.origin.y -= 30
                    self.coin22.frame.origin.y -= 30
                    self.coin4.isHidden = true
                }
            }
            else if self.stairApear == 3{
                self.coin3.isHidden = false
                if self.wall == 3{
                    self.characterImageView.frame.origin.y -= 30
                    self.chess -= 6
                    
                    
                    self.stair4.frame.origin.y -= 30
                    self.stair3.frame.origin.y -= 30
                    self.stair2.frame.origin.y -= 30
                    self.stair1.frame.origin.y -= 30
                    self.stair0.frame.origin.y -= 30
                    self.stair11.frame.origin.y -= 30
                    self.stair22.frame.origin.y -= 30
                    self.coin4.frame.origin.y -= 30
                    self.coin3.frame.origin.y -= 30
                    self.coin2.frame.origin.y -= 30
                    self.coin1.frame.origin.y -= 30
                    self.coin0.frame.origin.y -= 30
                    self.coin11.frame.origin.y -= 30
                    self.coin22.frame.origin.y -= 30
                    self.coin3.isHidden = true
                }
            }
            else if self.stairApear == 2{
                self.coin2.isHidden = false
                if self.wall == 2{
                    self.characterImageView.frame.origin.y -= 30
                    self.chess -= 6
                    
                    
                    self.stair4.frame.origin.y -= 30
                    self.stair3.frame.origin.y -= 30
                    self.stair2.frame.origin.y -= 30
                    self.stair1.frame.origin.y -= 30
                    self.stair0.frame.origin.y -= 30
                    self.stair11.frame.origin.y -= 30
                    self.stair22.frame.origin.y -= 30
                    self.coin4.frame.origin.y -= 30
                    self.coin3.frame.origin.y -= 30
                    self.coin2.frame.origin.y -= 30
                    self.coin1.frame.origin.y -= 30
                    self.coin0.frame.origin.y -= 30
                    self.coin11.frame.origin.y -= 30
                    self.coin22.frame.origin.y -= 30
                    self.coin2.isHidden = true
                }
            }
            else if self.stairApear == 1{
                self.coin1.isHidden = false
                if self.wall == 1{
                    self.characterImageView.frame.origin.y -= 30
                    self.chess -= 6
                    
                  
                    self.stair4.frame.origin.y -= 30
                    self.stair3.frame.origin.y -= 30
                    self.stair2.frame.origin.y -= 30
                    self.stair1.frame.origin.y -= 30
                    self.stair0.frame.origin.y -= 30
                    self.stair11.frame.origin.y -= 30
                    self.stair22.frame.origin.y -= 30
                    self.coin4.frame.origin.y -= 30
                    self.coin3.frame.origin.y -= 30
                    self.coin2.frame.origin.y -= 30
                    self.coin1.frame.origin.y -= 30
                    self.coin0.frame.origin.y -= 30
                    self.coin11.frame.origin.y -= 30
                    self.coin22.frame.origin.y -= 30
                    self.coin1.isHidden = true
                }
            }
            else if self.stairApear == 0{
                self.coin0.isHidden = false
                if self.wall == 0{
                    self.characterImageView.frame.origin.y -= 30
                    self.chess -= 6
                    
                   
                    self.stair4.frame.origin.y -= 30
                    self.stair3.frame.origin.y -= 30
                    self.stair2.frame.origin.y -= 30
                    self.stair1.frame.origin.y -= 30
                    self.stair0.frame.origin.y -= 30
                    self.stair11.frame.origin.y -= 30
                    self.stair22.frame.origin.y -= 30
                    self.coin4.frame.origin.y -= 30
                    self.coin3.frame.origin.y -= 30
                    self.coin2.frame.origin.y -= 30
                    self.coin1.frame.origin.y -= 30
                    self.coin0.frame.origin.y -= 30
                    self.coin11.frame.origin.y -= 30
                    self.coin22.frame.origin.y -= 30
                    self.coin0.isHidden = true
                }
            }
            else if self.stairApear == -1{
                self.coin11.isHidden = false
                if self.wall == -1{
                    self.characterImageView.frame.origin.y -= 30
                    self.chess -= 6
                    
                   
                    self.stair4.frame.origin.y -= 30
                    self.stair3.frame.origin.y -= 30
                    self.stair2.frame.origin.y -= 30
                    self.stair1.frame.origin.y -= 30
                    self.stair0.frame.origin.y -= 30
                    self.stair11.frame.origin.y -= 30
                    self.stair22.frame.origin.y -= 30
                    self.coin4.frame.origin.y -= 30
                    self.coin3.frame.origin.y -= 30
                    self.coin2.frame.origin.y -= 30
                    self.coin1.frame.origin.y -= 30
                    self.coin0.frame.origin.y -= 30
                    self.coin11.frame.origin.y -= 30
                    self.coin22.frame.origin.y -= 30
                    self.coin11.isHidden = true
                }
            }
            else if self.stairApear == -2{
                self.coin22.isHidden = false
                if self.wall == -2{
                    self.characterImageView.frame.origin.y -= 30
                    self.chess -= 6
                    
                
                    self.stair4.frame.origin.y -= 30
                    self.stair3.frame.origin.y -= 30
                    self.stair2.frame.origin.y -= 30
                    self.stair1.frame.origin.y -= 30
                    self.stair0.frame.origin.y -= 30
                    self.stair11.frame.origin.y -= 30
                    self.stair22.frame.origin.y -= 30
                    self.coin4.frame.origin.y -= 30
                    self.coin3.frame.origin.y -= 30
                    self.coin2.frame.origin.y -= 30
                    self.coin1.frame.origin.y -= 30
                    self.coin0.frame.origin.y -= 30
                    self.coin11.frame.origin.y -= 30
                    self.coin22.frame.origin.y -= 30
                    self.coin22.isHidden = true
                }
            }
            if self.chess >= 45 || self.chess <= -15{
                if self.timer != nil{
                    self.timer?.invalidate()
                }
                if self.timer2 != nil{
                    self.timer2?.invalidate()
                }
                if self.wall >= 0{
                    if(self.pickCharacter==self.Rose.player){
                        self.characterImageView.image = #imageLiteral(resourceName: "rose3")
                    }
                    else if(self.pickCharacter==self.Lisa.player){
                        self.characterImageView.image = #imageLiteral(resourceName: "Lisa3")
                    }
                    else if(self.pickCharacter==self.Jennie.player){
                        self.characterImageView.image = #imageLiteral(resourceName: "jennie3")
                    }
                    else if(self.pickCharacter==self.Jisoo.player){
                        self.characterImageView.image = #imageLiteral(resourceName: "jisoo3")
                    }
                }
                else if self.wall < 0{
                    if(self.pickCharacter==self.Rose.player){
                        self.characterImageView.image = #imageLiteral(resourceName: "rose3-2")
                    }
                    else if(self.pickCharacter==self.Lisa.player){
                        self.characterImageView.image = #imageLiteral(resourceName: "Lisa3-2")
                    }
                    else if(self.pickCharacter==self.Jennie.player){
                        self.characterImageView.image = #imageLiteral(resourceName: "jennie3-2")
                    }
                    else if(self.pickCharacter==self.Jisoo.player){
                        self.characterImageView.image = #imageLiteral(resourceName: "jisoo3-2")
                    }
                }
                self.startORpause = 0
            }
            }
            
        }
        
        else {
            if timer != nil{
                timer?.invalidate()
            }
            if timer2 != nil{
                timer2?.invalidate()
            }
            startORpause = 0
        }
        
    }
    
    
    
    @IBAction func turnLeftbuttom(_ sender: Any) {
        if startORpause == 1{
        if wall == -2{
            if(pickCharacter==Rose.player){
                characterImageView.image = #imageLiteral(resourceName: "rose1-2")
            }
            else if(pickCharacter==Lisa.player){
                characterImageView.image = #imageLiteral(resourceName: "Lisa1-2")
            }
            else if(pickCharacter==Jennie.player){
                characterImageView.image = #imageLiteral(resourceName: "jennie1-2")
            }
            else if(pickCharacter==Jisoo.player){
                characterImageView.image = #imageLiteral(resourceName: "jisoo1-2")
            }
        } 
        else{
        if steps == 1{
            if(pickCharacter==Rose.player){
                characterImageView.image = #imageLiteral(resourceName: "rose2-2")
            }
            else if(pickCharacter==Lisa.player){
                characterImageView.image = #imageLiteral(resourceName: "Lisa2-2")
            }
            else if(pickCharacter==Jennie.player){
                characterImageView.image = #imageLiteral(resourceName: "jennie2-2")
            }
            else if(pickCharacter==Jisoo.player){
                characterImageView.image = #imageLiteral(resourceName: "jisoo2-2")
            }
            steps += 1
            wall -= 1
            characterImageView.frame.origin.x -= 50
        }
        else if steps == 0{
            if(pickCharacter==Rose.player){
                characterImageView.image = #imageLiteral(resourceName: "rose2-2")
            }
            else if(pickCharacter==Lisa.player){
                characterImageView.image = #imageLiteral(resourceName: "Lisa2-2")
            }
            else if(pickCharacter==Jennie.player){
                characterImageView.image = #imageLiteral(resourceName: "jennie2-2")
            }
            else if(pickCharacter==Jisoo.player){
                characterImageView.image = #imageLiteral(resourceName: "jisoo2-2")
            }
            steps += 2
            wall -= 1
            characterImageView.frame.origin.x -= 50
        }
        else if steps == 3{
            if(pickCharacter==Rose.player){
                characterImageView.image = #imageLiteral(resourceName: "rose2-2")
            }
            else if(pickCharacter==Lisa.player){
                characterImageView.image = #imageLiteral(resourceName: "Lisa2-2")
            }
            else if(pickCharacter==Jennie.player){
                characterImageView.image = #imageLiteral(resourceName: "jennie2-2")
            }
            else if(pickCharacter==Jisoo.player){
                characterImageView.image = #imageLiteral(resourceName: "jisoo2-2")
            }
            steps -= 1
            wall -= 1
            characterImageView.frame.origin.x -= 50
        }
        else if steps == 2{
            if(pickCharacter==Rose.player){
                characterImageView.image = #imageLiteral(resourceName: "rose1-2")
            }
            else if(pickCharacter==Lisa.player){
                characterImageView.image = #imageLiteral(resourceName: "Lisa1-2")
            }
            else if(pickCharacter==Jennie.player){
                characterImageView.image = #imageLiteral(resourceName: "jennie1-2")
            }
            else if(pickCharacter==Jisoo.player){
                characterImageView.image = #imageLiteral(resourceName: "jisoo1-2")
            }
            steps += 1
            wall -= 1
            characterImageView.frame.origin.x -= 50
        }
        }
        }
        else{
            
        }
    }
    @IBAction func turnRightbuttom(_ sender: Any) {
        if startORpause == 1 {
        if wall == 4{
            if(pickCharacter==Rose.player){
                characterImageView.image = #imageLiteral(resourceName: "rose1")
            }
            else if(pickCharacter==Lisa.player){
                characterImageView.image = #imageLiteral(resourceName: "Lisa1")
            }
            else if(pickCharacter==Jennie.player){
                characterImageView.image = #imageLiteral(resourceName: "jennie1")
            }
            else if(pickCharacter==Jisoo.player){
                characterImageView.image = #imageLiteral(resourceName: "jisoo1")
            }
        }
        else{
        if steps == 1{
            if(pickCharacter==Rose.player){
                characterImageView.image = #imageLiteral(resourceName: "rose1")
            }
            else if(pickCharacter==Lisa.player){
                characterImageView.image = #imageLiteral(resourceName: "Lisa1")
            }
            else if(pickCharacter==Jennie.player){
                characterImageView.image = #imageLiteral(resourceName: "jennie1")
            }
            else if(pickCharacter==Jisoo.player){
                characterImageView.image = #imageLiteral(resourceName: "jisoo1")
            }
            steps -= 1
            wall += 1
            characterImageView.frame.origin.x += 50
        }
        else if steps == 0{
            if(pickCharacter==Rose.player){
                characterImageView.image = #imageLiteral(resourceName: "rose2")
            }
            else if(pickCharacter==Lisa.player){
                characterImageView.image = #imageLiteral(resourceName: "Lisa2")
            }
            else if(pickCharacter==Jennie.player){
                characterImageView.image = #imageLiteral(resourceName: "jennie2")
            }
            else if(pickCharacter==Jisoo.player){
                characterImageView.image = #imageLiteral(resourceName: "jisoo2")
            }
            steps += 1
            wall += 1
            characterImageView.frame.origin.x += 50
        }
        else if steps == 2{
            if(pickCharacter==Rose.player){
                characterImageView.image = #imageLiteral(resourceName: "rose2")
            }
            else if(pickCharacter==Lisa.player){
                characterImageView.image = #imageLiteral(resourceName: "Lisa2")
            }
            else if(pickCharacter==Jennie.player){
                characterImageView.image = #imageLiteral(resourceName: "jennie2")
            }
            else if(pickCharacter==Jisoo.player){
                characterImageView.image = #imageLiteral(resourceName: "jisoo2")
            }
            steps -= 1
            wall += 1
            characterImageView.frame.origin.x += 50
        }
        else if steps == 3{
            if(pickCharacter==Rose.player){
                characterImageView.image = #imageLiteral(resourceName: "rose2")
            }
            else if(pickCharacter==Lisa.player){
                characterImageView.image = #imageLiteral(resourceName: "Lisa2")
            }
            else if(pickCharacter==Jennie.player){
                characterImageView.image = #imageLiteral(resourceName: "jennie2")
            }
            else if(pickCharacter==Jisoo.player){
                characterImageView.image = #imageLiteral(resourceName: "jisoo2")
            }
            steps -= 2
            wall += 1
            characterImageView.frame.origin.x += 50
        }
        }
    }
        else{
            
        }
    }
    
}

