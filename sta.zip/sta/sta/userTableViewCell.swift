//
//  userTableViewCell.swift
//  sta
//
//  Created by User16 on 2019/6/19.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit

class userTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
