//
//  signUPViewController.swift
//  sta
//
//  Created by User16 on 2019/6/18.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit

class signUPViewController: UIViewController,UITextFieldDelegate {
    @IBOutlet weak var aaccount: UITextField!
    
    @IBOutlet weak var warning: UIImageView!
    @IBOutlet weak var register: UIButton!
    @IBOutlet weak var uusername: UITextField!
    @IBOutlet weak var ppassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        aaccount.delegate = self
        uusername.delegate = self
        ppassword.delegate = self
        register.clipsToBounds = true
        register.layer.cornerRadius = 10
        
        
        // Do any additional setup after loading the view.
    }
    var i :Int = 0
    @IBAction func signUP(_ sender: Any) {
        let userAccount = aaccount.text ?? ""
        let userPassword = ppassword.text ?? ""
        let userName = uusername.text ?? ""
        let url = URL(string: "https://sheetdb.io/api/v1/5qemd699oou25/search?Account=\(userAccount)&casesensitive=true")
        var urlRequest = URLRequest(url: url!)
        urlRequest.httpMethod = "GET"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let task = URLSession.shared.dataTask(with: urlRequest){(data,response,error)in
            let decoder = JSONDecoder()
            if let data = data,let decodedData = try? decoder.decode([[String:String]].self,from: data){
                DispatchQueue.main.async {
                if decodedData == []{
                    self.i = 1
                    self.warning.isHidden = false
                    self.warning.image = #imageLiteral(resourceName: "checked")
                    let url = URL(string: "https://sheetdb.io/api/v1/5qemd699oou25")
                    var urlRequest = URLRequest(url: url!)
                    urlRequest.httpMethod = "POST"
                    urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    let user = User(Account: userAccount, Password: userPassword, Name: userName)
                    let userData = UserData(data: [user])
                    
                    let encoder = JSONEncoder()
                    if let data = try? encoder.encode(userData) {
                        let task = URLSession.shared.uploadTask(with: urlRequest, from: data, completionHandler: { (reData, res, err) in
                            let decoder = JSONDecoder()
                            if let reData = reData, let statusCode = try? decoder.decode([String: Int].self, from: reData), statusCode["created"] == 1 {
                                print("ok")
                            } else {
                                print("error")
                            }
                        })
                        task.resume()
                    }

                }
                else{
                    self.warning.isHidden = false
                    self.warning.image = #imageLiteral(resourceName: "cancel")
                }
                
            }}
        }
        task.resume()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
