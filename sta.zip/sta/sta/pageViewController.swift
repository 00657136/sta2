//
//  pageViewController.swift
//  sta
//
//  Created by User15 on 2019/5/14.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit

class pageViewController: UIViewController {

    @IBOutlet weak var press: UIButton!
    @IBOutlet weak var Rose: UIImageView!
    @IBOutlet weak var Jisoo: UIImageView!
    @IBOutlet weak var Jennie: UIImageView!
    @IBOutlet weak var Lisa: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { (_) in
            if self.i == 1{
                self.i -= 1
                self.Jisoo.image = #imageLiteral(resourceName: "jisoo2")
                self.Lisa.image = #imageLiteral(resourceName: "Lisa2")
                self.Jennie.image = #imageLiteral(resourceName: "jennie2")
                self.Rose.image = #imageLiteral(resourceName: "rose2")
                self.press.isHidden = true
            }
            else{
                self.i += 1
                self.Jisoo.image = #imageLiteral(resourceName: "jisoo1")
                self.Lisa.image = #imageLiteral(resourceName: "Lisa1")
                self.Jennie.image = #imageLiteral(resourceName: "jennie1")
                self.Rose.image = #imageLiteral(resourceName: "rose1")
                self.press.isHidden = false
            }
        }
        // Do any additional setup after loading the view.
    }
    var i:Int = 0
    var timer : Timer?

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
