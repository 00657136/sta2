//
//  loginViewController.swift
//  sta
//
//  Created by User16 on 2019/6/18.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit
import Foundation

class loginViewController: UIViewController ,UITextFieldDelegate{

    var alertAccountNotExist = UIAlertController(title: "登入失敗", message: "帳號不存在", preferredStyle: .alert)
    var alertWrongPassword = UIAlertController(title: "登入失敗", message: "密碼錯誤", preferredStyle: .alert)
    var okAction = UIAlertAction(title: "確認", style: .cancel, handler: nil)
    
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var ppassword: UITextField!
    @IBOutlet weak var aaccouunt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        aaccouunt.delegate = self
        ppassword.delegate = self
        login.clipsToBounds = true
        login.layer.cornerRadius = 10
        
        alertAccountNotExist.addAction(self.okAction)
        alertWrongPassword.addAction(self.okAction)
        // Do any additional setup after loading the view.
    }
    
    

    
    @IBAction func clickTologin(_ sender: Any) {
        
        let userAccount = aaccouunt.text ?? ""
        let userPassword = ppassword.text ?? ""
        
        let url = URL(string: "https://sheetdb.io/api/v1/5qemd699oou25/search?Account=\(userAccount)&casesensitive=true")
        var urlRequest = URLRequest(url: url!)
        urlRequest.httpMethod = "GET"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            let decoder = JSONDecoder()
            if let data = data, let decodedData = try? decoder.decode([[String: String]].self, from: data){
                print("get succeed")
                print(decodedData)
                print(type(of: decodedData))
                
                DispatchQueue.main.async {
                    if decodedData == [] {
                        print("NO This Account")
                        
                        self.present(self.alertAccountNotExist, animated: true)
                    } else if decodedData[0]["Password"] != userPassword {
                        print("Wrong Password")
                        
                        self.present(self.alertWrongPassword, animated: true)
                    } else {
                        print("LogIn suceed")
                        self.userName = decodedData[0]["Name"]
                        UserDefaults.standard.set(self.aaccouunt.text, forKey: "userAccount")
                        UserDefaults.standard.set(self.userName, forKey: "userName")
                        UserDefaults.standard.set(self.ppassword.text, forKey: "userPassword")
                        self.performSegue(withIdentifier: "segue_logIn", sender: sender)
                        
                    }
                }
                
                
            } else {
                print("task failed")
            }
        }
        task.resume()
        
        
    }
    
    
    
    var userName: String?
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        //UserDefaults.standard.set("peter", forKey: "name")
        //UserDefaults.standard.string(forKey: "name")
        
        if segue.identifier == "segue_logIn" {
            let accounttabBar = segue.destination as! accounttabBar
            accounttabBar.userAccount = aaccouunt.text
            accounttabBar.userName = userName
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
