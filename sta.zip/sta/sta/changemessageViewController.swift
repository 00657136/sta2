//
//  changemessageViewController.swift
//  sta
//
//  Created by User15 on 2019/6/21.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit
import Foundation
class changemessageViewController: UIViewController ,UITextFieldDelegate,UINavigationControllerDelegate{
    @IBOutlet weak var messagetextfield: UITextField!
    @IBOutlet weak var checked: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //\(account ?? "")
        // Do any additional setup after loading the view.
    }
    var messagee:String!
var account:String!
    var name:String!
    var password:String!
    
    @IBAction func storeMessage(_ sender: Any) {
        
        let userDefault = UserDefaults.standard
        account = userDefault.string(forKey: "userAccount")
       name = userDefault.string(forKey: "userName")
       password = userDefault.string(forKey: "userPassword")
        let messagee = messagetextfield.text ?? ""
        
        let url = URL(string: "https://sheetdb.io/api/v1/5qemd699oou25/search?Account=98&casesensitive=true")
        
        var urlRequest = URLRequest(url: url!)
        urlRequest.httpMethod = "GET"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            let decoder = JSONDecoder()
            if let data = data, let decodedData = try? decoder.decode([[String: String]].self, from: data){
                print("get succeed")
                print(decodedData)
                print(type(of: decodedData))
                
                DispatchQueue.main.async {
                   
                        //
                        let url = URL(string: "https://sheetdb.io/api/v1/5qemd699oou25")
                        var urlRequest = URLRequest(url: url!)
                        urlRequest.httpMethod = "POST"
                        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
                    let user = Message(Account: self.account, Password: self.password, Name: self.name, message: messagee)
                        let messageData = MessageData(data: [user])
                        print(messageData)
                        let encoder = JSONEncoder()
                        if let data = try? encoder.encode(messageData) {
                            let task = URLSession.shared.uploadTask(with: urlRequest, from: data, completionHandler: { (reData, res, err) in
                                let decoder = JSONDecoder()
                                if let reData = reData, let statusCode = try? decoder.decode([String: Int].self, from: reData), statusCode["created"] == 1 {
                                    DispatchQueue.main.async {
                                    print("ok")
                                        self.checked.isHidden = false
                                        UserDefaults.standard.set(self.messagetextfield.text , forKey: "usermessage")
                                    }
                                    
                                } else {
                                    print("error")
                                }
                            })
                            task.resume()
                        }
                        
                    
                   
                }
                
                
            } else {
                print("task failed")
            }
        }
        task.resume()
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
