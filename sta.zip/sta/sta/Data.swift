//
//  Data.swift
//  sta
//
//  Created by User16 on 2019/6/18.
//  Copyright © 2019 bear. All rights reserved.
//

import Foundation

struct User:Codable {
    var Account: String
    var Password: String
    var Name: String
}
struct UserData:Codable {
    var data: [User]
}

struct Message:Codable {
  
    var Account: String
    var Password: String
    var Name: String
    var message: String
}
struct  MessageData:Codable {
    var data : [Message]
}


