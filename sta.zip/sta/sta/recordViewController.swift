//
//  recordViewController.swift
//  sta
//
//  Created by User15 on 2019/5/14.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit

class recordViewController: UIViewController {
    var bestMinute:Int=0
    var bestSecond:Int=0
    var M:Int = 0
    var S:Int = 0
    var achievementscore:Int!
    
    @IBOutlet weak var Record: UILabel!
    @IBOutlet weak var BestRecord: UILabel!
    override func viewDidLoad() {
        
        achievementscore = bestMinute*60 + bestSecond
        
        UserDefaults.standard.set(achievementscore, forKey:"Int")
        
        super.viewDidLoad()
        if S < 10{
            Record.text = "\(M):0\(S)"
        }
        else if S >= 10{
            Record.text = "\(M):\(S)"
        }
       
            if bestSecond < 10{
                BestRecord.text = "\(bestMinute):0\(bestSecond)"
            }
            else if bestSecond >= 10{
                BestRecord.text = "\(bestMinute):\(bestSecond)"
            }
        

            if bestSecond < 10{
                BestRecord.text = "\(bestMinute):0\(bestSecond)"
            }
            else if bestSecond >= 10{
                BestRecord.text = "\(bestMinute):\(bestSecond)"
            }
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
